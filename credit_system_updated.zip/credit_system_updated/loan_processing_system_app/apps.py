from django.apps import AppConfig


class LoanProcessingSystemAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'loan_processing_system_app'
