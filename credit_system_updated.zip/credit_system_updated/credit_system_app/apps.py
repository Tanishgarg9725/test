from django.apps import AppConfig


class CreditSystemAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'credit_system_app'
