# credit_system/credit_system_app/models.py

from django.db import models

class Customer(models.Model):
    # The assignment mentions 'customer_id' in customer_data.xlsx.
    # We'll use Django's auto-ID as the primary key and store the Excel customer_id here.
    customer_id = models.IntegerField(unique=True, null=True, blank=True)

    first_name = models.CharField(max_length=100) # 
    last_name = models.CharField(max_length=100) # 
    phone_number = models.CharField(max_length=20, unique=True) # 
    monthly_salary = models.DecimalField(max_digits=10, decimal_places=2) # 
    approved_limit = models.DecimalField(max_digits=10, decimal_places=2) # 
    current_debt = models.DecimalField(max_digits=10, decimal_places=2, default=0.00) # 

    # Field for credit score, will be updated during eligibility checks.
    credit_score = models.IntegerField(default=0)

    # The API request body for /register also includes 'age'.
    # We should add it to the Customer model. 
    age = models.IntegerField(null=True, blank=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name} (ID: {self.customer_id or self.pk})"

class Loan(models.Model):
    # The assignment mentions 'loan_id' in loan_data.xlsx.
    # Similar to customer_id, we use Django's auto-ID and store the Excel loan_id.
    loan_id = models.IntegerField(unique=True, null=True, blank=True)

    # Foreign Key to the Customer model
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='loans') # 

    loan_amount = models.DecimalField(max_digits=10, decimal_places=2) # 
    tenure = models.IntegerField() # In months 
    interest_rate = models.DecimalField(max_digits=5, decimal_places=2) # 
    monthly_repayment = models.DecimalField(max_digits=10, decimal_places=2) # EMI 
    emis_paid_on_time = models.IntegerField() # 
    start_date = models.DateField() # 
    end_date = models.DateField() # 

    # Additional fields for loan status (e.g., whether it's active, approved, etc.)
    # This can be useful for eligibility checks like "sum of current loans".
    status = models.CharField(max_length=20, default='pending') # e.g., 'pending', 'approved', 'rejected', 'closed'

    def __str__(self):
        return f"Loan {self.loan_id or self.pk} for {self.customer.first_name} (Amount: {self.loan_amount})"